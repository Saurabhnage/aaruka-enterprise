"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { ArrowRight, Star, Shield, Leaf, Sparkles, Play } from "lucide-react"

export default function EnhancedHero() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isVisible, setIsVisible] = useState(false)

  const slides = [
    {
      title: "Pure Earth. Pure Skin.",
      subtitle: "Ancient Beauty Secrets from Vadodara",
      description:
        "Experience the healing power of 100% organic Multani Mitti, handcrafted with love and trusted by generations.",
      image: "/placeholder.svg?height=600&width=500",
      cta: "Shop Now",
    },
    {
      title: "Nature's Gift to Your Skin",
      subtitle: "Chemical-Free • Hand-Processed • Premium Quality",
      description:
        "Discover the transformative power of authentic Fuller's Earth, sourced directly from Gujarat's mineral-rich soil.",
      image: "/placeholder.svg?height=600&width=500",
      cta: "Explore Products",
    },
  ]

  useEffect(() => {
    setIsVisible(true)
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 6000)
    return () => clearInterval(timer)
  }, [slides.length])

  return (
    <section id="home" className="relative min-h-screen flex items-center hero-gradient-enhanced overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-32 h-32 bg-terracotta/10 rounded-full blur-3xl animate-float"></div>
        <div
          className="absolute bottom-20 right-10 w-40 h-40 bg-sage/10 rounded-full blur-3xl animate-float"
          style={{ animationDelay: "2s" }}
        ></div>
        <div
          className="absolute top-1/2 left-1/4 w-24 h-24 bg-clay/10 rounded-full blur-2xl animate-float"
          style={{ animationDelay: "4s" }}
        ></div>
      </div>

      <div className="container-custom relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center min-h-screen py-20">
          {/* Enhanced Content */}
          <div className={`space-y-10 ${isVisible ? "animate-slide-in-left" : "opacity-0"}`}>
            {/* Premium Badge */}
            <div className="inline-flex items-center space-x-3 bg-white/90 backdrop-blur-md px-6 py-3 rounded-full shadow-xl border border-white/20">
              <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                ))}
              </div>
              <span className="text-sm font-semibold text-gray-700">4.9/5 from 1000+ customers</span>
              <Sparkles className="h-4 w-4 text-terracotta" />
            </div>

            {/* Main Heading with Enhanced Typography */}
            <div className="space-y-6">
              <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold leading-tight">
                <span className="text-gradient-enhanced">{slides[currentSlide].title}</span>
              </h1>
              <p className="text-2xl md:text-3xl text-gray-600 font-light leading-relaxed">
                {slides[currentSlide].subtitle}
              </p>
              <p className="text-xl text-gray-700 max-w-2xl leading-relaxed">{slides[currentSlide].description}</p>
            </div>

            {/* Enhanced Feature Pills */}
            <div className="flex flex-wrap gap-4">
              {[
                { icon: Shield, text: "100% Natural", color: "bg-green-100 text-green-700" },
                { icon: Leaf, text: "Chemical-Free", color: "bg-sage/20 text-sage" },
                { icon: Star, text: "Premium Quality", color: "bg-yellow-100 text-yellow-700" },
              ].map((feature, index) => (
                <div
                  key={index}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-full ${feature.color} backdrop-blur-sm`}
                >
                  <feature.icon className="h-5 w-5" />
                  <span className="font-medium">{feature.text}</span>
                </div>
              ))}
            </div>

            {/* Enhanced CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-6 pt-6">
              <a href="#products" className="btn-primary group flex items-center justify-center">
                <span>{slides[currentSlide].cta}</span>
                <ArrowRight className="ml-3 h-6 w-6 group-hover:translate-x-2 transition-transform duration-300" />
              </a>
              <button className="btn-secondary group flex items-center justify-center">
                <Play className="mr-3 h-5 w-5" />
                <span>Watch Story</span>
              </button>
            </div>

            {/* Enhanced Trust Indicators */}
            <div className="pt-10 border-t border-white/20">
              <div className="grid grid-cols-3 gap-8 text-center">
                {[
                  { value: "10K+", label: "Happy Customers", icon: "👥" },
                  { value: "100%", label: "Natural", icon: "🌿" },
                  { value: "5★", label: "Rating", icon: "⭐" },
                ].map((stat, index) => (
                  <div key={index} className="group">
                    <div className="text-4xl mb-2">{stat.icon}</div>
                    <div className="text-3xl font-bold text-terracotta group-hover:scale-110 transition-transform duration-300">
                      {stat.value}
                    </div>
                    <div className="text-sm text-gray-600 font-medium">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Enhanced Image Section */}
          <div className={`relative ${isVisible ? "animate-slide-in-right" : "opacity-0"}`}>
            <div className="relative z-10">
              {/* Main Product Image */}
              <div className="relative group">
                <Image
                  src={slides[currentSlide].image || "/placeholder.svg"}
                  alt="Aaruka Enterprise Multani Mitti Products"
                  width={600}
                  height={700}
                  className="rounded-3xl shadow-2xl group-hover:scale-105 transition-transform duration-700"
                  priority
                />

                {/* Floating Elements */}
                <div className="absolute -top-6 -right-6 bg-white/90 backdrop-blur-md p-4 rounded-2xl shadow-xl animate-float">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-terracotta">₹299</div>
                    <div className="text-sm text-gray-600">Starting from</div>
                  </div>
                </div>

                <div
                  className="absolute -bottom-6 -left-6 bg-white/90 backdrop-blur-md p-4 rounded-2xl shadow-xl animate-float"
                  style={{ animationDelay: "1s" }}
                >
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-sm font-medium text-gray-700">In Stock</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Enhanced Decorative Elements */}
            <div className="absolute -top-8 -right-8 w-32 h-32 bg-gradient-to-r from-terracotta/20 to-clay/20 rounded-full blur-2xl"></div>
            <div className="absolute -bottom-8 -left-8 w-40 h-40 bg-gradient-to-r from-sage/20 to-forest/20 rounded-full blur-2xl"></div>
          </div>
        </div>

        {/* Enhanced Slide Indicators */}
        <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2 flex space-x-3">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-4 h-4 rounded-full transition-all duration-300 ${
                index === currentSlide ? "bg-terracotta scale-125 shadow-lg" : "bg-white/50 hover:bg-white/70"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
