"use client"

import { useRef, useEffect, useState } from "react"

interface VideoTransitionProps {
  currentVideo: string
  nextVideo: string
  isTransitioning: boolean
  onTransitionComplete: () => void
  className?: string
}

export default function VideoTransition({
  currentVideo,
  nextVideo,
  isTransitioning,
  onTransitionComplete,
  className = "",
}: VideoTransitionProps) {
  const currentVideoRef = useRef<HTMLVideoElement>(null)
  const nextVideoRef = useRef<HTMLVideoElement>(null)
  const [transitionType, setTransitionType] = useState<"fade" | "slide" | "zoom">("fade")

  useEffect(() => {
    if (isTransitioning) {
      // Randomly select transition type
      const transitions: ("fade" | "slide" | "zoom")[] = ["fade", "slide", "zoom"]
      setTransitionType(transitions[Math.floor(Math.random() * transitions.length)])

      // Complete transition after animation
      const timer = setTimeout(() => {
        onTransitionComplete()
      }, 1000)

      return () => clearTimeout(timer)
    }
  }, [isTransitioning, onTransitionComplete])

  const getTransitionClasses = () => {
    if (!isTransitioning) return ""

    switch (transitionType) {
      case "slide":
        return "transform translate-x-full"
      case "zoom":
        return "transform scale-110"
      case "fade":
      default:
        return "opacity-0"
    }
  }

  return (
    <div className={`relative ${className}`}>
      {/* Current Video */}
      <video
        ref={currentVideoRef}
        autoPlay
        muted
        loop
        playsInline
        className={`absolute inset-0 w-full h-full object-cover transition-all duration-1000 ${
          isTransitioning ? getTransitionClasses() : "opacity-100"
        }`}
      >
        <source src={currentVideo} type="video/mp4" />
      </video>

      {/* Next Video */}
      <video
        ref={nextVideoRef}
        autoPlay
        muted
        loop
        playsInline
        className={`absolute inset-0 w-full h-full object-cover transition-all duration-1000 ${
          isTransitioning ? "opacity-100 transform-none" : "opacity-0"
        }`}
      >
        <source src={nextVideo} type="video/mp4" />
      </video>
    </div>
  )
}
