"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { Quote, Heart, Sparkles, Award, Target, Users, Leaf, ArrowRight } from "lucide-react"

export default function FounderStory() {
  const [isVisible, setIsVisible] = useState(false)
  const [activeTab, setActiveTab] = useState("journey")
  const sectionRef = useRef<HTMLDivElement>(null)

  const founderData = {
    name: "Priya Mehta",
    title: "Founder & CEO",
    location: "Vadodara, Gujarat",
    experience: "15+ Years in Natural Wellness",
    image: "/placeholder.svg?height=400&width=400",
  }

  const tabs = [
    { id: "journey", label: "My Journey", icon: Heart },
    { id: "vision", label: "Vision", icon: Target },
    { id: "values", label: "Values", icon: Sparkles },
  ]

  const journeyMilestones = [
    {
      year: "2008",
      title: "The Beginning",
      description: "Started experimenting with grandmother's traditional recipes in my kitchen",
      icon: "🌱",
    },
    {
      year: "2015",
      title: "First Success",
      description: "Friends and family began requesting my homemade Multani Mitti preparations",
      icon: "✨",
    },
    {
      year: "2019",
      title: "Aaruka Born",
      description: "Officially launched Aaruka Enterprise with a mission to share authentic natural skincare",
      icon: "🚀",
    },
    {
      year: "2024",
      title: "Growing Impact",
      description: "Serving 10,000+ customers across India with pure, traditional wellness products",
      icon: "🌟",
    },
  ]

  useEffect(() => {
    // Some browsers/extensions disable IntersectionObserver
    if (typeof window === "undefined" || !("IntersectionObserver" in window)) {
      // Fallback: simply reveal the section
      setIsVisible(true)
      return
    }

    const target = sectionRef.current
    if (!target) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.disconnect() // stop observing after first reveal
        }
      },
      { threshold: 0.1 },
    )

    observer.observe(target)

    // Cleanup guard to avoid disconnecting an already-gone observer
    return () => {
      try {
        observer.disconnect()
      } catch {
        /* no-op */
      }
    }
  }, [])

  const renderContent = () => {
    switch (activeTab) {
      case "journey":
        return (
          <div className="space-y-12">
            {/* Personal Quote Section */}
            <div className="bg-gradient-to-r from-terracotta/10 to-sage/10 p-8 rounded-3xl border-2 border-terracotta/20">
              <div className="text-center">
                <Quote className="h-12 w-12 text-terracotta mx-auto mb-4" />
                <blockquote className="text-xl text-gray-700 italic leading-relaxed mb-6">
                  "My journey with Aaruka began in my grandmother's kitchen, where I first witnessed the magic of
                  Multani Mitti. As a young girl suffering from acne, I was skeptical of this simple clay. But after
                  just one week of using her homemade face pack, my skin transformed completely."
                </blockquote>
                <div className="w-16 h-1 bg-terracotta mx-auto mb-4 rounded-full"></div>
                <p className="text-gray-600 leading-relaxed">
                  That moment changed everything. I realized that the most powerful skincare solutions weren't found in
                  expensive bottles, but in the wisdom passed down through generations.
                </p>
              </div>
            </div>

            {/* Timeline Section - Horizontal Layout */}
            <div className="space-y-8">
              <div className="text-center">
                <h3 className="text-3xl font-bold text-gray-900 mb-4">My Journey Timeline</h3>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  From a personal discovery to building a brand that touches thousands of lives
                </p>
              </div>

              {/* Horizontal Timeline Grid */}
              <div className="grid md:grid-cols-2 gap-6">
                {journeyMilestones.map((milestone, index) => (
                  <div
                    key={milestone.year}
                    className={`relative transition-all duration-700 ${isVisible ? "animate-scale-in" : "opacity-0"}`}
                    style={{ animationDelay: `${index * 150}ms` }}
                  >
                    {/* Horizontal Content Card */}
                    <div className="bg-white/90 backdrop-blur-sm p-6 rounded-3xl shadow-xl border border-white/20 group hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 h-full">
                      <div className="flex items-start space-x-4">
                        {/* Icon and Year */}
                        <div className="flex-shrink-0">
                          <div className="w-16 h-16 bg-gradient-to-r from-terracotta to-clay rounded-full flex items-center justify-center text-2xl shadow-xl border-4 border-white mb-3">
                            {milestone.icon}
                          </div>
                          <div className="text-center">
                            <span className="bg-gradient-to-r from-terracotta to-clay text-white px-3 py-1 rounded-full text-xs font-bold shadow-lg">
                              {milestone.year}
                            </span>
                          </div>
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <h4 className="text-xl font-bold text-gray-900 group-hover:text-terracotta transition-colors duration-300 mb-3">
                            {milestone.title}
                          </h4>
                          <p className="text-gray-600 leading-relaxed text-sm mb-4">{milestone.description}</p>

                          {/* Progress indicator */}
                          <div className="flex items-center space-x-2">
                            <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                              <div
                                className="h-full bg-gradient-to-r from-terracotta to-sage rounded-full transition-all duration-1000"
                                style={{ width: `${((index + 1) / journeyMilestones.length) * 100}%` }}
                              ></div>
                            </div>
                            <span className="text-xs text-gray-500 font-medium">
                              {index + 1}/{journeyMilestones.length}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Decorative Corner Element */}
                      <div className="absolute top-4 right-4 w-8 h-8 bg-gradient-to-br from-terracotta/20 to-sage/20 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    </div>

                    {/* Connection Lines for Desktop */}
                    {index < journeyMilestones.length - 1 && index % 2 === 0 && (
                      <div className="hidden md:block absolute top-1/2 -right-3 w-6 h-0.5 bg-gradient-to-r from-terracotta to-sage transform -translate-y-1/2 z-10"></div>
                    )}
                  </div>
                ))}
              </div>

              {/* Overall Progress Bar */}
            </div>

            {/* Call to Action */}
            <div className="text-center bg-white/90 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-white/20">
              <h4 className="text-2xl font-bold text-gray-900 mb-4">Continue the Journey</h4>
              <p className="text-gray-600 mb-6">
                Every jar of Aaruka carries this story forward. Join thousands who have made natural skincare their
                choice.
              </p>
              <a
                href="#products"
                className="inline-flex items-center bg-gradient-to-r from-terracotta to-clay text-white px-8 py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
              >
                <Heart className="mr-2 h-5 w-5" />
                <span>Explore Our Products</span>
              </a>
            </div>
          </div>
        )

      case "vision":
        return (
          <div className="space-y-8">
            <div className="bg-gradient-to-r from-terracotta/10 to-sage/10 p-8 rounded-3xl border border-terracotta/20">
              <div className="flex items-start space-x-4">
                <Target className="h-8 w-8 text-terracotta flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">My Vision for Aaruka</h3>
                  <p className="text-lg text-gray-700 leading-relaxed mb-4">
                    "I envision Aaruka as more than just a skincare brand. We're a bridge between ancient wisdom and
                    modern needs, bringing the healing power of Indian soil to every home."
                  </p>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white/90 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-white/20">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-sage/20 rounded-full flex items-center justify-center">
                    <Leaf className="h-6 w-6 text-sage" />
                  </div>
                  <h4 className="text-xl font-bold text-gray-900">Sustainability First</h4>
                </div>
                <p className="text-gray-600">
                  Every product we create respects the earth. From sourcing to packaging, we ensure minimal
                  environmental impact while maximizing natural benefits.
                </p>
              </div>

              <div className="bg-white/90 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-white/20">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-terracotta/20 rounded-full flex items-center justify-center">
                    <Users className="h-6 w-6 text-terracotta" />
                  </div>
                  <h4 className="text-xl font-bold text-gray-900">Community Impact</h4>
                </div>
                <p className="text-gray-600">
                  We work directly with local farmers and artisans in Gujarat, ensuring fair trade and supporting rural
                  communities that preserve traditional knowledge.
                </p>
              </div>

              <div className="bg-white/90 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-white/20">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-clay/20 rounded-full flex items-center justify-center">
                    <Award className="h-6 w-6 text-clay" />
                  </div>
                  <h4 className="text-xl font-bold text-gray-900">Quality Promise</h4>
                </div>
                <p className="text-gray-600">
                  Every batch is personally tested and approved. We never compromise on purity, ensuring each product
                  meets the highest standards of natural wellness.
                </p>
              </div>

              <div className="bg-white/90 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-white/20">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-forest/20 rounded-full flex items-center justify-center">
                    <Heart className="h-6 w-6 text-forest" />
                  </div>
                  <h4 className="text-xl font-bold text-gray-900">Personal Touch</h4>
                </div>
                <p className="text-gray-600">
                  Each order is prepared with the same care I would give to my own family. Your skin's health is my
                  personal responsibility.
                </p>
              </div>
            </div>
          </div>
        )

      case "values":
        return (
          <div className="space-y-8">
            <div className="bg-white/90 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-white/20">
              <div className="flex items-start space-x-4 mb-6">
                <Sparkles className="h-8 w-8 text-terracotta flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">Core Values That Guide Us</h3>
                  <p className="text-lg text-gray-700 leading-relaxed">
                    These principles shape every decision we make at Aaruka, from product development to customer
                    service.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              {[
                {
                  title: "Authenticity",
                  description:
                    "We stay true to traditional recipes and methods, never compromising on the authentic preparation techniques passed down through generations.",
                  icon: "🏺",
                  color: "terracotta",
                },
                {
                  title: "Transparency",
                  description:
                    "Every ingredient, every process, every decision is made with complete transparency. Our customers deserve to know exactly what they're putting on their skin.",
                  icon: "🔍",
                  color: "sage",
                },
                {
                  title: "Respect for Nature",
                  description:
                    "We source responsibly, package sustainably, and ensure our practices honor the earth that provides our healing clay.",
                  icon: "🌍",
                  color: "forest",
                },
                {
                  title: "Customer First",
                  description:
                    "Every customer is treated like family. Their skin concerns become our mission, their satisfaction our success.",
                  icon: "💝",
                  color: "clay",
                },
              ].map((value, index) => (
                <div
                  key={value.title}
                  className={`flex items-start space-x-6 transition-all duration-700 ${
                    isVisible ? "animate-slide-in-right" : "opacity-0"
                  }`}
                  style={{ animationDelay: `${index * 150}ms` }}
                >
                  <div className="flex-shrink-0">
                    <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-2xl shadow-lg border-4 border-terracotta/20">
                      {value.icon}
                    </div>
                  </div>
                  <div className="bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-white/20 flex-1">
                    <h4 className="text-xl font-bold text-gray-900 mb-3">{value.title}</h4>
                    <p className="text-gray-600 leading-relaxed">{value.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <section
      id="founder"
      ref={sectionRef}
      className="section-padding bg-gradient-to-br from-white via-earth-light to-earth-medium relative overflow-hidden"
    >
      {/* Enhanced Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Primary Gradient Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-white via-earth-light to-earth-medium"></div>

        {/* Animated Gradient Overlays */}
        <div className="absolute inset-0 bg-gradient-to-r from-terracotta/5 via-transparent to-sage/5 animate-pulse"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-transparent via-clay/3 to-transparent"></div>

        {/* Geometric Pattern Layer */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23CD853F' fillOpacity='0.15'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            backgroundSize: "60px 60px",
          }}
        />

        {/* Floating Decorative Elements */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-r from-terracotta/10 to-clay/10 rounded-full blur-3xl animate-float"></div>
        <div
          className="absolute top-40 right-20 w-24 h-24 bg-gradient-to-r from-sage/10 to-forest/10 rounded-full blur-2xl animate-float"
          style={{ animationDelay: "2s" }}
        ></div>
        <div
          className="absolute bottom-32 left-1/4 w-40 h-40 bg-gradient-to-r from-clay/8 to-terracotta/8 rounded-full blur-3xl animate-float"
          style={{ animationDelay: "4s" }}
        ></div>
        <div
          className="absolute bottom-20 right-10 w-28 h-28 bg-gradient-to-r from-forest/10 to-sage/10 rounded-full blur-2xl animate-float"
          style={{ animationDelay: "6s" }}
        ></div>

        {/* Subtle Texture Overlay */}
        <div
          className="absolute inset-0 opacity-5 mix-blend-multiply"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23CD853F' fillOpacity='0.05'%3E%3Cpath d='M50 50m-20 0a20 20 0 1 1 40 0a20 20 0 1 1 -40 0'/%3E%3C/g%3E%3C/svg%3E")`,
            backgroundSize: "100px 100px",
          }}
        />

        {/* Light Rays Effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-transparent via-white/5 to-transparent transform rotate-12"></div>
        <div className="absolute inset-0 bg-gradient-to-tl from-transparent via-terracotta/3 to-transparent transform -rotate-12"></div>
      </div>

      <div className="container-custom relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-terracotta/10 px-4 py-2 rounded-full mb-4">
            <Heart className="h-4 w-4 text-terracotta" />
            <span className="text-sm font-semibold text-terracotta">Meet the Founder</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            The Heart Behind <span className="text-gradient-enhanced">Aaruka</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover the personal journey, vision, and values that drive our commitment to authentic natural skincare
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Founder Profile */}
          <div
            className={`transition-all duration-1000 ${isVisible ? "animate-slide-in-left" : "opacity-0 translate-x-[-50px]"}`}
          >
            <div className="bg-white/95 backdrop-blur-md rounded-3xl p-8 shadow-2xl border border-white/20">
              <div className="text-center mb-8">
                <div className="relative inline-block">
                  <Image
                    src={founderData.image || "/placeholder.svg"}
                    alt={founderData.name}
                    width={200}
                    height={200}
                    className="w-48 h-48 rounded-full mx-auto shadow-2xl border-4 border-white"
                  />
                  <div className="absolute -bottom-4 -right-4 bg-terracotta text-white p-3 rounded-full shadow-lg">
                    <Heart className="h-6 w-6" />
                  </div>
                </div>

                <div className="mt-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{founderData.name}</h3>
                  <p className="text-terracotta font-semibold mb-1">{founderData.title}</p>
                  <p className="text-gray-600 text-sm mb-2">{founderData.location}</p>
                  <p className="text-gray-500 text-sm">{founderData.experience}</p>
                </div>
              </div>

              {/* Personal Quote */}
              <div className="bg-gradient-to-r from-terracotta/10 to-sage/10 p-6 rounded-2xl border border-terracotta/20">
                <Quote className="h-6 w-6 text-terracotta mb-3" />
                <p className="text-gray-700 italic leading-relaxed mb-3">
                  "Every jar of Aaruka carries not just clay, but centuries of wisdom, love, and the promise of natural
                  healing. This is my gift to you."
                </p>
                <div className="text-right">
                  <span className="text-terracotta font-semibold">— {founderData.name}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Content Tabs */}
          <div
            className={`transition-all duration-1000 ${isVisible ? "animate-slide-in-right" : "opacity-0 translate-x-[50px]"}`}
          >
            {/* Tab Navigation */}
            <div className="flex space-x-2 mb-8 bg-white/80 backdrop-blur-sm p-2 rounded-2xl shadow-lg">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 flex items-center justify-center space-x-2 py-3 px-4 rounded-xl font-semibold transition-all duration-300 ${
                    activeTab === tab.id
                      ? "bg-terracotta text-white shadow-lg"
                      : "text-gray-600 hover:text-terracotta hover:bg-terracotta/10"
                  }`}
                >
                  <tab.icon className="h-5 w-5" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="min-h-[600px]">{renderContent()}</div>

            {/* Call to Action */}
            <div className="mt-8 text-center">
              <a
                href="#contact"
                className="inline-flex items-center bg-gradient-to-r from-terracotta to-clay text-white px-8 py-4 rounded-xl font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
              >
                <span>Connect with Me</span>
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
