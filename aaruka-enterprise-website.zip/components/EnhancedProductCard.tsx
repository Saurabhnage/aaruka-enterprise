"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { Star, ShoppingCart, Heart, Loader2, Eye, Zap } from "lucide-react"

interface Product {
  id: string
  name: string
  price: number
  originalPrice?: number
  rating: number
  reviews: number
  image: string
  benefits: string[]
  weight: string
  description: string
  badge?: string
}

interface EnhancedProductCardProps {
  product: Product
}

declare global {
  interface Window {
    Razorpay: any
  }
}

export default function EnhancedProductCard({ product }: EnhancedProductCardProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [isLiked, setIsLiked] = useState(false)
  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    email: "",
    phone: "",
  })
  const [showCheckout, setShowCheckout] = useState(false)

  const handleBuyNow = async () => {
    if (!customerInfo.name || !customerInfo.email) {
      setShowCheckout(true)
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch("/api/razorpay", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: product.price,
          currency: "INR",
          receipt: `receipt_${product.id}_${Date.now()}`,
          notes: {
            product_id: product.id,
            product_name: product.name,
            customer_name: customerInfo.name,
            customer_email: customerInfo.email,
          },
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to create order")
      }

      const order = await response.json()

      // Check if this is prototype mode (mock key)
      if (order.key === "rzp_test_prototype_key") {
        // Prototype mode - simulate successful payment
        console.log("Prototype mode: Simulating successful payment")
        setTimeout(() => {
          window.location.href = `/thank-you?payment_id=pay_prototype_${Date.now()}&order_id=${order.id}`
        }, 2000)
        return
      }

      // Production mode - use actual Razorpay
      if (typeof window.Razorpay === "undefined") {
        throw new Error("Razorpay SDK not loaded")
      }

      const options = {
        key: order.key,
        amount: order.amount,
        currency: order.currency,
        name: "Aaruka Enterprise",
        description: product.name,
        image: "/logo.png",
        order_id: order.id,
        prefill: {
          name: customerInfo.name,
          email: customerInfo.email,
          contact: customerInfo.phone,
        },
        theme: {
          color: "#CD853F",
        },
        handler: (response: any) => {
          window.location.href = `/thank-you?payment_id=${response.razorpay_payment_id}&order_id=${response.razorpay_order_id}`
        },
        modal: {
          ondismiss: () => {
            setIsLoading(false)
          },
        },
      }

      const rzp = new window.Razorpay(options)
      rzp.open()
    } catch (error) {
      console.error("Payment error:", error)
      alert("Payment failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleCustomerInfoSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setShowCheckout(false)
    handleBuyNow()
  }

  return (
    <>
      <div className="product-card group overflow-hidden">
        {/* Enhanced Product Image */}
        <div className="relative overflow-hidden">
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            width={400}
            height={300}
            className="w-full h-72 object-cover group-hover:scale-110 transition-transform duration-700"
          />

          {/* Enhanced Badges */}
          <div className="absolute top-4 left-4 flex flex-col gap-2">
            {product.originalPrice && (
              <div className="bg-gradient-to-r from-red-500 to-red-600 text-white px-3 py-1 rounded-full text-sm font-bold shadow-lg">
                {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
              </div>
            )}
            {product.badge && (
              <div className="bg-gradient-to-r from-terracotta to-clay text-white px-3 py-1 rounded-full text-sm font-bold shadow-lg">
                {product.badge}
              </div>
            )}
          </div>

          {/* Enhanced Action Buttons */}
          <div className="absolute top-4 right-4 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button
              onClick={() => setIsLiked(!isLiked)}
              className="bg-white/90 backdrop-blur-sm p-3 rounded-full hover:bg-white transition-all duration-300 shadow-lg"
            >
              <Heart className={`h-5 w-5 ${isLiked ? "text-red-500 fill-current" : "text-gray-600"}`} />
            </button>
            <button className="bg-white/90 backdrop-blur-sm p-3 rounded-full hover:bg-white transition-all duration-300 shadow-lg">
              <Eye className="h-5 w-5 text-gray-600" />
            </button>
          </div>

          {/* Quick Buy Overlay */}
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
            <button
              onClick={handleBuyNow}
              className="bg-white text-terracotta px-6 py-3 rounded-full font-bold transform scale-90 group-hover:scale-100 transition-transform duration-300 shadow-xl"
            >
              Quick Buy (Demo)
            </button>
          </div>
        </div>

        {/* Enhanced Product Info */}
        <div className="p-8">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-terracotta font-bold uppercase tracking-wider bg-terracotta/10 px-3 py-1 rounded-full">
              {product.weight}
            </span>
            <div className="flex items-center space-x-1 bg-yellow-50 px-3 py-1 rounded-full">
              <Star className="h-4 w-4 text-yellow-400 fill-current" />
              <span className="text-sm font-bold text-yellow-700">{product.rating}</span>
              <span className="text-sm text-gray-500">({product.reviews})</span>
            </div>
          </div>

          <h3 className="text-2xl font-bold text-gray-900 mb-3 group-hover:text-terracotta transition-colors duration-300">
            {product.name}
          </h3>
          <p className="text-gray-600 mb-4 leading-relaxed">{product.description}</p>

          {/* Enhanced Benefits */}
          <div className="flex flex-wrap gap-2 mb-6">
            {product.benefits.slice(0, 3).map((benefit, index) => (
              <span
                key={index}
                className="bg-gradient-to-r from-sage/10 to-forest/10 text-sage text-xs px-3 py-2 rounded-full font-medium border border-sage/20"
              >
                {benefit}
              </span>
            ))}
            {product.benefits.length > 3 && (
              <span className="text-xs text-gray-500 px-3 py-2">+{product.benefits.length - 3} more</span>
            )}
          </div>

          {/* Enhanced Price */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <span className="text-3xl font-bold text-gray-900">₹{product.price}</span>
              {product.originalPrice && (
                <span className="text-xl text-gray-500 line-through">₹{product.originalPrice}</span>
              )}
            </div>
            <div className="flex items-center space-x-1 text-green-600">
              <Zap className="h-4 w-4" />
              <span className="text-sm font-medium">Fast Delivery</span>
            </div>
          </div>

          {/* Enhanced Buy Button */}
          <button
            onClick={handleBuyNow}
            disabled={isLoading}
            className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed group"
          >
            {isLoading ? (
              <div className="flex items-center justify-center">
                <Loader2 className="h-6 w-6 mr-3 animate-spin" />
                Processing Demo...
              </div>
            ) : (
              <div className="flex items-center justify-center">
                <ShoppingCart className="h-6 w-6 mr-3 group-hover:scale-110 transition-transform duration-300" />
                Buy Now - Demo Payment
              </div>
            )}
          </button>
        </div>
      </div>

      {/* Enhanced Customer Info Modal */}
      {showCheckout && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-8 shadow-2xl animate-scale-in">
            <div className="text-center mb-6">
              <div className="bg-terracotta/10 p-4 rounded-full w-16 h-16 mx-auto mb-4">
                <ShoppingCart className="h-8 w-8 text-terracotta mx-auto" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Complete Your Purchase</h3>
              <p className="text-gray-600">Demo checkout - no real payment required</p>
            </div>

            <form onSubmit={handleCustomerInfoSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  id="name"
                  required
                  value={customerInfo.name}
                  onChange={(e) => setCustomerInfo((prev) => ({ ...prev, name: e.target.value }))}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-terracotta focus:border-terracotta transition-all duration-300"
                  placeholder="Enter your full name"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  id="email"
                  required
                  value={customerInfo.email}
                  onChange={(e) => setCustomerInfo((prev) => ({ ...prev, email: e.target.value }))}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-terracotta focus:border-terracotta transition-all duration-300"
                  placeholder="Enter your email"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-semibold text-gray-700 mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  id="phone"
                  value={customerInfo.phone}
                  onChange={(e) => setCustomerInfo((prev) => ({ ...prev, phone: e.target.value }))}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-terracotta focus:border-terracotta transition-all duration-300"
                  placeholder="+91 98765 43210"
                />
              </div>

              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setShowCheckout(false)} className="flex-1 btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="flex-1 btn-primary">
                  Proceed to Demo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  )
}
