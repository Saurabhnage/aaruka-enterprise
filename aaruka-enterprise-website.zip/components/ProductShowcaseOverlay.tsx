"use client"

import { useState } from "react"
import Image from "next/image"
import { Star, ShoppingCart, X, ArrowRight } from "lucide-react"

interface Product {
  id: string
  name: string
  price: number
  originalPrice?: number
  rating: number
  reviews: number
  image: string
  badge?: string
}

interface ProductShowcaseOverlayProps {
  products: Product[]
  isVisible: boolean
  onClose: () => void
}

export default function ProductShowcaseOverlay({ products, isVisible, onClose }: ProductShowcaseOverlayProps) {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)

  if (!isVisible) return null

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">Featured Products</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors duration-300">
            <X className="h-6 w-6 text-gray-600" />
          </button>
        </div>

        {/* Products Grid */}
        <div className="p-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <div
                key={product.id}
                className="bg-white border border-gray-200 rounded-2xl p-4 hover:shadow-lg transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedProduct(product)}
              >
                <div className="relative mb-4">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={200}
                    height={200}
                    className="w-full h-48 object-cover rounded-xl"
                  />
                  {product.badge && (
                    <div className="absolute top-2 left-2 bg-terracotta text-white px-2 py-1 rounded-full text-xs font-bold">
                      {product.badge}
                    </div>
                  )}
                  {product.originalPrice && (
                    <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                      {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                    </div>
                  )}
                </div>

                <h3 className="font-bold text-gray-900 mb-2">{product.name}</h3>

                <div className="flex items-center space-x-1 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                      }`}
                    />
                  ))}
                  <span className="text-sm text-gray-600 ml-2">({product.reviews})</span>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <span className="text-xl font-bold text-terracotta">₹{product.price}</span>
                    {product.originalPrice && (
                      <span className="text-sm text-gray-500 line-through">₹{product.originalPrice}</span>
                    )}
                  </div>
                </div>

                <button className="w-full bg-terracotta text-white py-2 rounded-lg font-semibold hover:bg-terracotta/90 transition-colors duration-300 flex items-center justify-center">
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Buy Now
                </button>
              </div>
            ))}
          </div>

          {/* View All Products Button */}
          <div className="text-center mt-8">
            <a
              href="#products"
              onClick={onClose}
              className="inline-flex items-center bg-gradient-to-r from-terracotta to-clay text-white px-8 py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-300"
            >
              View All Products
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </div>
        </div>
      </div>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-60 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6">
            <div className="flex justify-between items-start mb-6">
              <h3 className="text-2xl font-bold text-gray-900">{selectedProduct.name}</h3>
              <button onClick={() => setSelectedProduct(null)} className="text-gray-500 hover:text-gray-700 text-2xl">
                ×
              </button>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <Image
                src={selectedProduct.image || "/placeholder.svg"}
                alt={selectedProduct.name}
                width={300}
                height={300}
                className="w-full rounded-xl"
              />

              <div className="space-y-4">
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(selectedProduct.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                      }`}
                    />
                  ))}
                  <span className="ml-2 text-gray-600">({selectedProduct.reviews} reviews)</span>
                </div>

                <div className="flex items-center space-x-3">
                  <span className="text-3xl font-bold text-terracotta">₹{selectedProduct.price}</span>
                  {selectedProduct.originalPrice && (
                    <span className="text-xl text-gray-500 line-through">₹{selectedProduct.originalPrice}</span>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                    <span className="text-sm text-gray-700">100% Natural & Organic</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                    <span className="text-sm text-gray-700">Chemical-Free Formula</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                    <span className="text-sm text-gray-700">Suitable for All Skin Types</span>
                  </div>
                </div>

                <button className="w-full bg-gradient-to-r from-terracotta to-clay text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-300">
                  Add to Cart - ₹{selectedProduct.price}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
