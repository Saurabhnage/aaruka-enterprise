"use client"

import { useEffect, useState } from "react"

interface VideoPreloaderProps {
  videos: string[]
  onProgress: (loaded: number, total: number) => void
  onComplete: () => void
}

export default function VideoPreloader({ videos, onProgress, onComplete }: VideoPreloaderProps) {
  const [loadedCount, setLoadedCount] = useState(0)

  useEffect(() => {
    let loaded = 0
    const total = videos.length

    const preloadVideo = (src: string) => {
      return new Promise<void>((resolve) => {
        const video = document.createElement("video")
        video.src = src
        video.preload = "metadata"
        video.muted = true

        const handleLoad = () => {
          loaded++
          setLoadedCount(loaded)
          onProgress(loaded, total)
          resolve()
        }

        const handleError = () => {
          loaded++
          setLoadedCount(loaded)
          onProgress(loaded, total)
          resolve()
        }

        video.addEventListener("loadeddata", handleLoad)
        video.addEventListener("error", handleError)
      })
    }

    Promise.all(videos.map(preloadVideo)).then(() => {
      onComplete()
    })
  }, [videos, onProgress, onComplete])

  return null
}
