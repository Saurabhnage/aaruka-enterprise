"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { MapPin, Award, Users, Leaf, Heart, Sparkles } from "lucide-react"

export default function About() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLDivElement>(null)

  const stats = [
    { icon: Users, value: "10,000+", label: "Happy Customers", color: "text-terracotta" },
    { icon: Award, value: "5 Years", label: "Experience", color: "text-sage" },
    { icon: Leaf, value: "100%", label: "Natural Products", color: "text-forest" },
    { icon: MapPin, value: "Vadodara", label: "Gujarat, India", color: "text-clay" },
  ]

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="about" ref={sectionRef} className="section-padding bg-gradient-to-br from-earth-light to-white">
      <div className="container-custom">
        {/* Header Section */}
        <div className="text-center max-w-4xl mx-auto mb-20">
          <div className="inline-flex items-center space-x-2 bg-terracotta/10 px-4 py-2 rounded-full mb-6">
            <Heart className="h-4 w-4 text-terracotta" />
            <span className="text-sm font-semibold text-terracotta">Our Story</span>
          </div>

          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 leading-tight mb-6">
            The Story of <span className="text-gradient-enhanced">Aaruka</span>
          </h2>
          <p className="text-xl text-gray-600 leading-relaxed">
            Born from the ancient wisdom of Indian households and the rich soil of Vadodara
          </p>
        </div>

        {/* Main Content Section */}
        <div className="grid lg:grid-cols-2 gap-20 items-center mb-20">
          {/* Left Column - Story Content */}
          <div
            className={`space-y-8 transition-all duration-1000 ${isVisible ? "animate-slide-in-left" : "opacity-0 translate-x-[-50px]"}`}
          >
            <div className="space-y-6">
              <div className="bg-white/90 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-white/20">
                <p className="text-lg leading-relaxed text-gray-700">
                  In the heart of <strong className="text-terracotta">Vadodara</strong>, where ancient traditions still
                  whisper through the banyan leaves and the earth holds secrets passed down through generations,{" "}
                  <strong className="text-gradient">Aaruka Enterprise</strong> was born.
                </p>
              </div>

              <div className="bg-white/90 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-white/20">
                <p className="text-lg leading-relaxed text-gray-700">
                  Our story begins not in a lab, but in a <em className="text-sage font-semibold">kitchen garden</em>,
                  where a grandmother gently mixed sun-dried Multani Mitti with rose water for her granddaughter's first
                  skincare ritual. That moment — raw, real, and rooted in trust — planted the seed of what would become
                  Aaruka.
                </p>
              </div>

              <div className="bg-gradient-to-r from-terracotta/15 to-sage/15 p-8 rounded-3xl border-2 border-terracotta/20">
                <div className="text-center">
                  <p className="text-2xl font-bold text-terracotta mb-2">"Aaruka" means nurture</p>
                  <p className="text-lg text-gray-700 leading-relaxed">
                    And that is our purpose: To nurture your skin, your connection to nature, and the centuries-old
                    wisdom of Indian soil.
                  </p>
                </div>
              </div>

              <div className="bg-white/90 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-white/20">
                <p className="text-lg leading-relaxed text-gray-700">
                  At Aaruka Enterprise, we don't just sell clay — we{" "}
                  <strong className="text-sage">honor a ritual</strong>. Our Multani Mitti is sourced from the rich
                  mineral beds of India, untouched by chemicals, and dried under the Gujarat sun, just as our ancestors
                  once did.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column - Image and Visual Elements */}
          <div
            className={`relative transition-all duration-1000 ${isVisible ? "animate-slide-in-right" : "opacity-0 translate-x-[50px]"}`}
          >
            <div className="relative">
              {/* Main Image */}
              <div className="relative group">
                <Image
                  src="/placeholder.svg?height=600&width=500"
                  alt="Traditional Multani Mitti preparation in Vadodara"
                  width={500}
                  height={600}
                  className="w-full rounded-3xl shadow-2xl group-hover:scale-105 transition-transform duration-700"
                />

                {/* Floating Elements */}
                <div className="absolute top-6 left-6 bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-xl animate-float">
                  <div className="flex items-center space-x-2">
                    <Sparkles className="h-5 w-5 text-terracotta" />
                    <span className="font-bold text-gray-900">Since 2019</span>
                  </div>
                </div>

                <div
                  className="absolute bottom-6 right-6 bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-xl animate-float"
                  style={{ animationDelay: "1s" }}
                >
                  <div className="text-center">
                    <div className="text-2xl font-bold text-terracotta">100%</div>
                    <div className="text-sm text-gray-600">Natural</div>
                  </div>
                </div>
              </div>

              {/* Decorative Elements */}
              <div className="absolute -top-8 -right-8 w-32 h-32 bg-gradient-to-r from-sage/20 to-forest/20 rounded-full blur-2xl animate-float"></div>
              <div
                className="absolute -bottom-8 -left-8 w-40 h-40 bg-gradient-to-r from-terracotta/20 to-clay/20 rounded-full blur-2xl animate-float"
                style={{ animationDelay: "2s" }}
              ></div>
            </div>
          </div>
        </div>

        {/* Quote Section */}
        <div className="max-w-4xl mx-auto mb-20">
          <div className="bg-white/95 backdrop-blur-md p-10 rounded-3xl shadow-2xl border border-white/20 text-center">
            <div className="flex items-center justify-center space-x-1 mb-6">
              {[...Array(5)].map((_, i) => (
                <Sparkles key={i} className="h-5 w-5 text-terracotta" />
              ))}
            </div>
            <blockquote className="text-xl text-gray-700 italic leading-relaxed mb-6">
              "In a world obsessed with instant results and artificial beauty, we believe in slowing down, going back to
              the roots, and letting nature do the work."
            </blockquote>
            <div className="flex items-center justify-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-terracotta to-sage rounded-full flex items-center justify-center">
                <Heart className="h-6 w-6 text-white" />
              </div>
              <div className="text-left">
                <div className="font-bold text-terracotta">Aaruka Enterprise</div>
                <div className="text-sm text-gray-500">Vadodara, Gujarat</div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className={`text-center group transition-all duration-500 ${isVisible ? "animate-scale-in" : "opacity-0"}`}
              style={{ animationDelay: `${index * 200}ms` }}
            >
              <div className="bg-white/90 backdrop-blur-sm p-8 rounded-3xl shadow-xl group-hover:shadow-2xl transition-all duration-300 group-hover:-translate-y-3 border border-white/20">
                <div className="bg-gradient-to-br from-terracotta/10 to-sage/10 p-6 rounded-full w-20 h-20 mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <stat.icon className={`h-8 w-8 ${stat.color} mx-auto`} />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                <div className="text-sm text-gray-600 font-medium">{stat.label}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
