"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { ArrowRight, Star, Shield, Leaf, Sparkles, Play, Pause, Volume2, VolumeX } from "lucide-react"

export default function VideoHero() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isVisible, setIsVisible] = useState(false)
  const [isVideoPlaying, setIsVideoPlaying] = useState(true)
  const [isMuted, setIsMuted] = useState(true)
  const [showProductShowcase, setShowProductShowcase] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)

  const slides = [
    {
      title: "Pure Earth. Pure Skin.",
      subtitle: "Ancient Beauty Secrets from Vadodara",
      description:
        "Experience the healing power of 100% organic Multani Mitti, handcrafted with love and trusted by generations.",
      cta: "Shop Now",
      video: "/placeholder-video.mp4", // Replace with actual video URL
    },
    {
      title: "Nature's Gift to Your Skin",
      subtitle: "Chemical-Free • Hand-Processed • Premium Quality",
      description:
        "Discover the transformative power of authentic Fuller's Earth, sourced directly from Gujarat's mineral-rich soil.",
      cta: "Explore Products",
      video: "/placeholder-video-2.mp4", // Replace with actual video URL
    },
  ]

  const featuredProducts = [
    {
      id: 1,
      name: "Pure Multani Mitti Face Pack",
      price: 299,
      originalPrice: 399,
      image: "/placeholder.svg?height=200&width=200",
      rating: 4.9,
    },
    {
      id: 2,
      name: "Hair Mask",
      price: 349,
      originalPrice: 449,
      image: "/placeholder.svg?height=200&width=200",
      rating: 4.8,
    },
    {
      id: 3,
      name: "Combo Pack",
      price: 549,
      originalPrice: 748,
      image: "/placeholder.svg?height=200&width=200",
      rating: 4.9,
    },
  ]

  useEffect(() => {
    setIsVisible(true)
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 8000)
    return () => clearInterval(timer)
  }, [slides.length])

  useEffect(() => {
    // Show product showcase after 3 seconds
    const showcaseTimer = setTimeout(() => {
      setShowProductShowcase(true)
    }, 3000)
    return () => clearTimeout(showcaseTimer)
  }, [])

  const toggleVideoPlayback = () => {
    if (videoRef.current) {
      if (isVideoPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play()
      }
      setIsVideoPlaying(!isVideoPlaying)
    }
  }

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Video Background */}
      <div className="absolute inset-0 z-0">
        <video
          ref={videoRef}
          autoPlay
          muted={isMuted}
          loop
          playsInline
          className="w-full h-full object-cover"
          onLoadedData={() => console.log("Video loaded")}
          onError={() => console.log("Video error")}
        >
          <source src={slides[currentSlide].video} type="video/mp4" />
          {/* Fallback for browsers that don't support video */}
          <div className="w-full h-full bg-gradient-to-br from-earth-light via-earth-medium to-earth-dark"></div>
        </video>

        {/* Video Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-black/20 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent"></div>
      </div>

      {/* Video Controls */}
      <div className="absolute top-6 right-6 z-30 flex space-x-2">
        <button
          onClick={toggleVideoPlayback}
          className="bg-white/20 backdrop-blur-md p-3 rounded-full hover:bg-white/30 transition-all duration-300"
          aria-label={isVideoPlaying ? "Pause video" : "Play video"}
        >
          {isVideoPlaying ? <Pause className="h-5 w-5 text-white" /> : <Play className="h-5 w-5 text-white" />}
        </button>
        <button
          onClick={toggleMute}
          className="bg-white/20 backdrop-blur-md p-3 rounded-full hover:bg-white/30 transition-all duration-300"
          aria-label={isMuted ? "Unmute video" : "Mute video"}
        >
          {isMuted ? <VolumeX className="h-5 w-5 text-white" /> : <Volume2 className="h-5 w-5 text-white" />}
        </button>
      </div>

      {/* Floating Product Showcase */}
      <div
        className={`absolute top-20 right-8 z-20 transition-all duration-1000 ${
          showProductShowcase ? "translate-x-0 opacity-100" : "translate-x-full opacity-0"
        }`}
      >
        <div className="bg-white/95 backdrop-blur-md rounded-3xl p-6 shadow-2xl max-w-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-gray-900">Featured Products</h3>
            <button onClick={() => setShowProductShowcase(false)} className="text-gray-500 hover:text-gray-700 text-xl">
              ×
            </button>
          </div>

          <div className="space-y-3">
            {featuredProducts.map((product) => (
              <div
                key={product.id}
                className="flex items-center space-x-3 p-3 rounded-xl hover:bg-gray-50 transition-colors duration-300 cursor-pointer group"
              >
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  width={60}
                  height={60}
                  className="rounded-lg group-hover:scale-105 transition-transform duration-300"
                />
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900 text-sm">{product.name}</h4>
                  <div className="flex items-center space-x-1 mb-1">
                    <Star className="h-3 w-3 text-yellow-400 fill-current" />
                    <span className="text-xs text-gray-600">{product.rating}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-terracotta font-bold">₹{product.price}</span>
                    <span className="text-gray-500 line-through text-xs">₹{product.originalPrice}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button className="w-full mt-4 bg-terracotta text-white py-2 rounded-lg font-semibold hover:bg-terracotta/90 transition-colors duration-300">
            View All Products
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="container-custom relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center min-h-screen py-20">
          {/* Enhanced Content */}
          <div className={`space-y-10 ${isVisible ? "animate-slide-in-left" : "opacity-0"}`}>
            {/* Premium Badge */}
            <div className="inline-flex items-center space-x-3 bg-white/90 backdrop-blur-md px-6 py-3 rounded-full shadow-xl border border-white/20">
              <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                ))}
              </div>
              <span className="text-sm font-semibold text-gray-700">4.9/5 from 1000+ customers</span>
              <Sparkles className="h-4 w-4 text-terracotta" />
            </div>

            {/* Main Heading with Enhanced Typography */}
            <div className="space-y-6">
              <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold leading-tight text-white drop-shadow-2xl">
                <span className="bg-gradient-to-r from-white via-earth-light to-terracotta bg-clip-text text-transparent">
                  {slides[currentSlide].title}
                </span>
              </h1>
              <p className="text-2xl md:text-3xl text-white/90 font-light leading-relaxed drop-shadow-lg">
                {slides[currentSlide].subtitle}
              </p>
              <p className="text-xl text-white/80 max-w-2xl leading-relaxed drop-shadow-md">
                {slides[currentSlide].description}
              </p>
            </div>

            {/* Enhanced Feature Pills */}
            <div className="flex flex-wrap gap-4">
              {[
                { icon: Shield, text: "100% Natural", color: "bg-green-500/20 text-green-100 border-green-400/30" },
                { icon: Leaf, text: "Chemical-Free", color: "bg-sage/20 text-sage-100 border-sage/30" },
                { icon: Star, text: "Premium Quality", color: "bg-yellow-500/20 text-yellow-100 border-yellow-400/30" },
              ].map((feature, index) => (
                <div
                  key={index}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-full backdrop-blur-md border ${feature.color}`}
                >
                  <feature.icon className="h-5 w-5" />
                  <span className="font-medium">{feature.text}</span>
                </div>
              ))}
            </div>

            {/* Enhanced CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-6 pt-6">
              <a href="#products" className="btn-primary group flex items-center justify-center">
                <span>{slides[currentSlide].cta}</span>
                <ArrowRight className="ml-3 h-6 w-6 group-hover:translate-x-2 transition-transform duration-300" />
              </a>
              <button
                onClick={() => setShowProductShowcase(!showProductShowcase)}
                className="bg-white/20 backdrop-blur-md text-white border-2 border-white/30 hover:bg-white/30 px-8 py-4 rounded-xl font-semibold transition-all duration-300 flex items-center justify-center"
              >
                <Sparkles className="mr-3 h-5 w-5" />
                <span>View Products</span>
              </button>
            </div>

            {/* Enhanced Trust Indicators */}
            <div className="pt-10 border-t border-white/20">
              <div className="grid grid-cols-3 gap-8 text-center">
                {[
                  { value: "10K+", label: "Happy Customers", icon: "👥" },
                  { value: "100%", label: "Natural", icon: "🌿" },
                  { value: "5★", label: "Rating", icon: "⭐" },
                ].map((stat, index) => (
                  <div key={index} className="group">
                    <div className="text-4xl mb-2">{stat.icon}</div>
                    <div className="text-3xl font-bold text-white group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                      {stat.value}
                    </div>
                    <div className="text-sm text-white/80 font-medium">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Product Showcase Grid */}
          <div className={`relative ${isVisible ? "animate-slide-in-right" : "opacity-0"}`}>
            <div className="grid grid-cols-2 gap-6">
              {/* Main Product */}
              <div className="col-span-2 bg-white/95 backdrop-blur-md rounded-3xl p-6 shadow-2xl">
                <div className="flex items-center space-x-4">
                  <Image
                    src="/placeholder.svg?height=120&width=120"
                    alt="Featured Product"
                    width={120}
                    height={120}
                    className="rounded-2xl"
                  />
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Pure Multani Mitti Face Pack</h3>
                    <div className="flex items-center space-x-1 mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                      ))}
                      <span className="text-sm text-gray-600 ml-2">(234 reviews)</span>
                    </div>
                    <div className="flex items-center space-x-2 mb-3">
                      <span className="text-2xl font-bold text-terracotta">₹299</span>
                      <span className="text-lg text-gray-500 line-through">₹399</span>
                      <span className="bg-red-100 text-red-600 px-2 py-1 rounded-full text-xs font-bold">25% OFF</span>
                    </div>
                    <button className="w-full bg-terracotta text-white py-2 rounded-lg font-semibold hover:bg-terracotta/90 transition-colors duration-300">
                      Buy Now
                    </button>
                  </div>
                </div>
              </div>

              {/* Secondary Products */}
              {featuredProducts.slice(1).map((product, index) => (
                <div key={product.id} className="bg-white/90 backdrop-blur-md rounded-2xl p-4 shadow-xl">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={100}
                    height={100}
                    className="w-full h-24 object-cover rounded-lg mb-3"
                  />
                  <h4 className="font-semibold text-gray-900 text-sm mb-2">{product.name}</h4>
                  <div className="flex items-center space-x-1 mb-2">
                    <Star className="h-3 w-3 text-yellow-400 fill-current" />
                    <span className="text-xs text-gray-600">{product.rating}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-terracotta font-bold text-sm">₹{product.price}</span>
                    <button className="bg-terracotta/10 text-terracotta px-3 py-1 rounded-full text-xs font-semibold hover:bg-terracotta/20 transition-colors duration-300">
                      View
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Floating Elements */}
            <div className="absolute -top-6 -right-6 bg-white/90 backdrop-blur-md p-4 rounded-2xl shadow-xl animate-float">
              <div className="text-center">
                <div className="text-green-600 font-bold text-sm">✓ In Stock</div>
                <div className="text-xs text-gray-600">Fast Delivery</div>
              </div>
            </div>

            <div
              className="absolute -bottom-6 -left-6 bg-white/90 backdrop-blur-md p-4 rounded-2xl shadow-xl animate-float"
              style={{ animationDelay: "1s" }}
            >
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm font-medium text-gray-700">1000+ sold</span>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Slide Indicators */}
        <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2 flex space-x-3">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-4 h-4 rounded-full transition-all duration-300 ${
                index === currentSlide ? "bg-white scale-125 shadow-lg" : "bg-white/50 hover:bg-white/70"
              }`}
            />
          ))}
        </div>
      </div>

      {/* Video Progress Indicator */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20">
        <div
          className="h-full bg-terracotta transition-all duration-300"
          style={{ width: `${((currentSlide + 1) / slides.length) * 100}%` }}
        />
      </div>
    </section>
  )
}
