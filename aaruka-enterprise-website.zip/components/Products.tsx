import EnhancedProductCard from "./EnhancedProductCard"

// Update the products array with enhanced data
const products = [
  {
    id: "multani-face-pack",
    name: "Pure Multani Mitti Face Pack",
    price: 299,
    originalPrice: 399,
    rating: 4.9,
    reviews: 234,
    image: "/placeholder.svg?height=300&width=400",
    benefits: ["Deep Cleansing", "Oil Control", "Acne Treatment", "Natural Glow", "Pore Minimizing"],
    weight: "200g",
    description: "Premium quality Multani Mitti for deep cleansing and natural glow. Perfect for all skin types.",
    badge: "BESTSELLER",
  },
  {
    id: "multani-hair-mask",
    name: "Multani Mitti Hair Mask",
    price: 349,
    originalPrice: 449,
    rating: 4.8,
    reviews: 156,
    image: "/placeholder.svg?height=300&width=400",
    benefits: ["Scalp Detox", "Dandruff Control", "Hair Strengthening", "Natural Shine", "Volume Boost"],
    weight: "250g",
    description: "Nourishing hair mask that cleanses scalp and adds natural shine to your hair.",
    badge: "NEW",
  },
  {
    id: "combo-pack",
    name: "Complete Care Combo Pack",
    price: 549,
    originalPrice: 748,
    rating: 4.9,
    reviews: 89,
    image: "/placeholder.svg?height=300&width=400",
    benefits: ["Face + Hair Care", "Complete Detox", "Best Value", "Free Mixing Bowl", "Premium Quality"],
    weight: "200g + 250g",
    description: "Complete skincare solution with face pack and hair mask. Best value for money!",
    badge: "SAVE 27%",
  },
]

export default function Products() {
  return (
    <section id="products" className="section-padding bg-white">
      <div className="container-custom">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Our <span className="text-gradient">Products</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover our range of authentic Multani Mitti products, each crafted with care to bring you the best of
            nature's healing power
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <EnhancedProductCard key={product.id} product={product} />
          ))}
        </div>

        {/* Trust Badges */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div className="bg-earth-light p-6 rounded-2xl">
            <div className="text-2xl font-bold text-terracotta mb-2">Free Shipping</div>
            <div className="text-gray-600 text-sm">On orders above ₹500</div>
          </div>
          <div className="bg-earth-light p-6 rounded-2xl">
            <div className="text-2xl font-bold text-terracotta mb-2">100% Natural</div>
            <div className="text-gray-600 text-sm">No chemicals added</div>
          </div>
          <div className="bg-earth-light p-6 rounded-2xl">
            <div className="text-2xl font-bold text-terracotta mb-2">Easy Returns</div>
            <div className="text-gray-600 text-sm">7-day return policy</div>
          </div>
          <div className="bg-earth-light p-6 rounded-2xl">
            <div className="text-2xl font-bold text-terracotta mb-2">Secure Payment</div>
            <div className="text-gray-600 text-sm">Razorpay protected</div>
          </div>
        </div>
      </div>
    </section>
  )
}
