"use client"

import type React from "react"

import { useRef, useEffect, useState } from "react"

interface VideoBackgroundProps {
  src: string
  fallbackImage?: string
  className?: string
  children?: React.ReactNode
}

export default function VideoBackground({ src, fallbackImage, className = "", children }: VideoBackgroundProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isLoaded, setIsLoaded] = useState(false)
  const [hasError, setHasError] = useState(false)

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    const handleLoadedData = () => {
      setIsLoaded(true)
    }

    const handleError = () => {
      setHasError(true)
    }

    video.addEventListener("loadeddata", handleLoadedData)
    video.addEventListener("error", handleError)

    return () => {
      video.removeEventListener("loadeddata", handleLoadedData)
      video.removeEventListener("error", handleError)
    }
  }, [])

  return (
    <div className={`relative overflow-hidden ${className}`}>
      {/* Video Element */}
      {!hasError && (
        <video
          ref={videoRef}
          autoPlay
          muted
          loop
          playsInline
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
            isLoaded ? "opacity-100" : "opacity-0"
          }`}
        >
          <source src={src} type="video/mp4" />
        </video>
      )}

      {/* Fallback Background */}
      {(hasError || !isLoaded) && fallbackImage && (
        <div
          className="absolute inset-0 w-full h-full bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${fallbackImage})` }}
        />
      )}

      {/* Default Gradient Fallback */}
      {(hasError || !isLoaded) && !fallbackImage && (
        <div className="absolute inset-0 w-full h-full bg-gradient-to-br from-earth-light via-earth-medium to-earth-dark" />
      )}

      {/* Content Overlay */}
      {children}
    </div>
  )
}
