"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import Image from "next/image"
import {
  ArrowRight,
  Star,
  Shield,
  Leaf,
  Sparkles,
  Play,
  Pause,
  Volume2,
  VolumeX,
  ChevronLeft,
  ChevronRight,
  Grid3X3,
} from "lucide-react"

interface VideoSlide {
  id: string
  title: string
  subtitle: string
  description: string
  cta: string
  video: string
  thumbnail: string
  product: {
    name: string
    price: number
    originalPrice?: number
    rating: number
    reviews: number
    image: string
    benefits: string[]
    badge?: string
  }
  theme: {
    primary: string
    secondary: string
    accent: string
  }
}

export default function VideoGalleryHero() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isVisible, setIsVisible] = useState(false)
  const [isVideoPlaying, setIsVideoPlaying] = useState(true)
  const [isMuted, setIsMuted] = useState(true)
  const [showProductShowcase, setShowProductShowcase] = useState(false)
  const [showVideoGallery, setShowVideoGallery] = useState(false)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [preloadedVideos, setPreloadedVideos] = useState<Set<number>>(new Set())

  const currentVideoRef = useRef<HTMLVideoElement>(null)
  const nextVideoRef = useRef<HTMLVideoElement>(null)
  const autoPlayRef = useRef<NodeJS.Timeout>()

  const videoSlides: VideoSlide[] = [
    {
      id: "face-pack-showcase",
      title: "Pure Earth. Pure Skin.",
      subtitle: "Ancient Beauty Secrets from Vadodara",
      description:
        "Experience the healing power of 100% organic Multani Mitti, handcrafted with love and trusted by generations.",
      cta: "Shop Face Pack",
      video: "/placeholder-video.mp4",
      thumbnail: "/placeholder.svg?height=200&width=300",
      product: {
        name: "Pure Multani Mitti Face Pack",
        price: 299,
        originalPrice: 399,
        rating: 4.9,
        reviews: 234,
        image: "/placeholder.svg?height=300&width=300",
        benefits: ["Deep Cleansing", "Oil Control", "Acne Treatment", "Natural Glow"],
        badge: "BESTSELLER",
      },
      theme: {
        primary: "#CD853F",
        secondary: "#B8860B",
        accent: "#87A96B",
      },
    },
    {
      id: "hair-mask-showcase",
      title: "Nourish Your Roots",
      subtitle: "Traditional Hair Care • Scalp Detox • Natural Shine",
      description:
        "Transform your hair with our authentic Multani Mitti hair mask, enriched with natural minerals for healthy, lustrous hair.",
      cta: "Shop Hair Mask",
      video: "/placeholder-video-2.mp4",
      thumbnail: "/placeholder.svg?height=200&width=300",
      product: {
        name: "Multani Mitti Hair Mask",
        price: 349,
        originalPrice: 449,
        rating: 4.8,
        reviews: 156,
        image: "/placeholder.svg?height=300&width=300",
        benefits: ["Scalp Detox", "Dandruff Control", "Hair Strengthening", "Natural Shine"],
        badge: "NEW",
      },
      theme: {
        primary: "#87A96B",
        secondary: "#556B2F",
        accent: "#CD853F",
      },
    },
    {
      id: "combo-showcase",
      title: "Complete Care Solution",
      subtitle: "Face + Hair Care • Best Value • Premium Quality",
      description:
        "Get the complete Aaruka experience with our combo pack featuring both face and hair care essentials at an unbeatable price.",
      cta: "Shop Combo",
      video: "/placeholder-video.mp4",
      thumbnail: "/placeholder.svg?height=200&width=300",
      product: {
        name: "Complete Care Combo Pack",
        price: 549,
        originalPrice: 748,
        rating: 4.9,
        reviews: 89,
        image: "/placeholder.svg?height=300&width=300",
        benefits: ["Face + Hair Care", "Complete Detox", "Best Value", "Free Mixing Bowl"],
        badge: "SAVE 27%",
      },
      theme: {
        primary: "#B8860B",
        secondary: "#CD853F",
        accent: "#87A96B",
      },
    },
    {
      id: "premium-showcase",
      title: "Premium Collection",
      subtitle: "Handcrafted • Limited Edition • Ultra Pure",
      description:
        "Discover our premium collection of specially curated Multani Mitti products, sourced from the finest clay deposits.",
      cta: "Shop Premium",
      video: "/placeholder-video-2.mp4",
      thumbnail: "/placeholder.svg?height=200&width=300",
      product: {
        name: "Premium Multani Mitti Collection",
        price: 799,
        originalPrice: 999,
        rating: 5.0,
        reviews: 45,
        image: "/placeholder.svg?height=300&width=300",
        benefits: ["Ultra Pure", "Handcrafted", "Limited Edition", "Premium Packaging"],
        badge: "PREMIUM",
      },
      theme: {
        primary: "#8B4513",
        secondary: "#A0522D",
        accent: "#DAA520",
      },
    },
  ]

  const currentSlideData = videoSlides[currentSlide]

  // Preload videos
  const preloadVideo = useCallback(
    (index: number) => {
      if (preloadedVideos.has(index)) return

      const video = document.createElement("video")
      video.src = videoSlides[index].video
      video.preload = "metadata"
      video.muted = true

      video.addEventListener("loadeddata", () => {
        setPreloadedVideos((prev) => new Set([...prev, index]))
      })
    },
    [preloadedVideos, videoSlides],
  )

  // Auto-advance slides
  useEffect(() => {
    if (isVideoPlaying) {
      autoPlayRef.current = setInterval(() => {
        nextSlide()
      }, 10000) // 10 seconds per slide
    }

    return () => {
      if (autoPlayRef.current) {
        clearInterval(autoPlayRef.current)
      }
    }
  }, [currentSlide, isVideoPlaying])

  // Preload adjacent videos
  useEffect(() => {
    const nextIndex = (currentSlide + 1) % videoSlides.length
    const prevIndex = (currentSlide - 1 + videoSlides.length) % videoSlides.length

    preloadVideo(nextIndex)
    preloadVideo(prevIndex)
  }, [currentSlide, preloadVideo])

  useEffect(() => {
    setIsVisible(true)
    // Show product showcase after 4 seconds
    const showcaseTimer = setTimeout(() => {
      setShowProductShowcase(true)
    }, 4000)
    return () => clearTimeout(showcaseTimer)
  }, [])

  const nextSlide = useCallback(() => {
    if (isTransitioning) return
    setIsTransitioning(true)

    const nextIndex = (currentSlide + 1) % videoSlides.length

    // Smooth transition
    setTimeout(() => {
      setCurrentSlide(nextIndex)
      setIsTransitioning(false)
    }, 500)
  }, [currentSlide, isTransitioning, videoSlides.length])

  const prevSlide = useCallback(() => {
    if (isTransitioning) return
    setIsTransitioning(true)

    const prevIndex = (currentSlide - 1 + videoSlides.length) % videoSlides.length

    setTimeout(() => {
      setCurrentSlide(prevIndex)
      setIsTransitioning(false)
    }, 500)
  }, [currentSlide, isTransitioning, videoSlides.length])

  const goToSlide = (index: number) => {
    if (index === currentSlide || isTransitioning) return
    setIsTransitioning(true)

    setTimeout(() => {
      setCurrentSlide(index)
      setIsTransitioning(false)
    }, 500)
  }

  const toggleVideoPlayback = () => {
    if (currentVideoRef.current) {
      if (isVideoPlaying) {
        currentVideoRef.current.pause()
      } else {
        currentVideoRef.current.play()
      }
      setIsVideoPlaying(!isVideoPlaying)
    }
  }

  const toggleMute = () => {
    if (currentVideoRef.current) {
      currentVideoRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Video Background with Smooth Transitions */}
      <div className="absolute inset-0 z-0">
        {/* Current Video */}
        <video
          ref={currentVideoRef}
          key={`current-${currentSlide}`}
          autoPlay
          muted={isMuted}
          loop
          playsInline
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
            isTransitioning ? "opacity-0" : "opacity-100"
          }`}
          onLoadedData={() => console.log("Video loaded")}
        >
          <source src={currentSlideData.video} type="video/mp4" />
        </video>

        {/* Next Video (for smooth transitions) */}
        <video
          ref={nextVideoRef}
          autoPlay
          muted
          loop
          playsInline
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
            isTransitioning ? "opacity-100" : "opacity-0"
          }`}
        >
          <source src={videoSlides[(currentSlide + 1) % videoSlides.length].video} type="video/mp4" />
        </video>

        {/* Dynamic Video Overlay based on theme */}
        <div
          className="absolute inset-0 transition-all duration-1000"
          style={{
            background: `linear-gradient(135deg, ${currentSlideData.theme.primary}20 0%, ${currentSlideData.theme.secondary}10 50%, transparent 100%)`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
      </div>

      {/* Enhanced Video Controls */}
      <div className="absolute top-6 right-6 z-30 flex space-x-2">
        <button
          onClick={() => setShowVideoGallery(true)}
          className="bg-white/20 backdrop-blur-md p-3 rounded-full hover:bg-white/30 transition-all duration-300"
          aria-label="Show video gallery"
        >
          <Grid3X3 className="h-5 w-5 text-white" />
        </button>
        <button
          onClick={toggleVideoPlayback}
          className="bg-white/20 backdrop-blur-md p-3 rounded-full hover:bg-white/30 transition-all duration-300"
          aria-label={isVideoPlaying ? "Pause video" : "Play video"}
        >
          {isVideoPlaying ? <Pause className="h-5 w-5 text-white" /> : <Play className="h-5 w-5 text-white" />}
        </button>
        <button
          onClick={toggleMute}
          className="bg-white/20 backdrop-blur-md p-3 rounded-full hover:bg-white/30 transition-all duration-300"
          aria-label={isMuted ? "Unmute video" : "Mute video"}
        >
          {isMuted ? <VolumeX className="h-5 w-5 text-white" /> : <Volume2 className="h-5 w-5 text-white" />}
        </button>
      </div>

      {/* Video Navigation */}
      <div className="absolute left-6 top-1/2 transform -translate-y-1/2 z-30">
        <button
          onClick={prevSlide}
          disabled={isTransitioning}
          className="bg-white/20 backdrop-blur-md p-4 rounded-full hover:bg-white/30 transition-all duration-300 disabled:opacity-50"
        >
          <ChevronLeft className="h-6 w-6 text-white" />
        </button>
      </div>

      <div className="absolute right-6 top-1/2 transform -translate-y-1/2 z-30">
        <button
          onClick={nextSlide}
          disabled={isTransitioning}
          className="bg-white/20 backdrop-blur-md p-4 rounded-full hover:bg-white/30 transition-all duration-300 disabled:opacity-50"
        >
          <ChevronRight className="h-6 w-6 text-white" />
        </button>
      </div>

      {/* Main Content */}
      <div className="container-custom relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center min-h-screen py-20">
          {/* Enhanced Content with Theme Colors */}
          <div
            className={`space-y-10 transition-all duration-1000 ${isVisible ? "animate-slide-in-left" : "opacity-0"}`}
          >
            {/* Premium Badge */}
            <div className="inline-flex items-center space-x-3 bg-white/90 backdrop-blur-md px-6 py-3 rounded-full shadow-xl border border-white/20">
              <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                ))}
              </div>
              <span className="text-sm font-semibold text-gray-700">4.9/5 from 1000+ customers</span>
              <Sparkles className="h-4 w-4" style={{ color: currentSlideData.theme.primary }} />
            </div>

            {/* Main Heading with Dynamic Colors */}
            <div className="space-y-6">
              <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold leading-tight transition-all duration-1000">
                <span
                  style={{
                    color: currentSlideData.theme.primary,
                  }}
                >
                  {currentSlideData.title}
                </span>
              </h1>
              <p className="text-2xl md:text-3xl text-white/90 font-light leading-relaxed drop-shadow-lg transition-all duration-1000">
                {currentSlideData.subtitle}
              </p>
              <p className="text-xl text-white/80 max-w-2xl leading-relaxed drop-shadow-md transition-all duration-1000">
                {currentSlideData.description}
              </p>
            </div>

            {/* Enhanced Feature Pills with Theme Colors */}
            <div className="flex flex-wrap gap-4">
              {[
                { icon: Shield, text: "100% Natural" },
                { icon: Leaf, text: "Chemical-Free" },
                { icon: Star, text: "Premium Quality" },
              ].map((feature, index) => (
                <div
                  key={index}
                  className="flex items-center space-x-2 px-4 py-2 rounded-full backdrop-blur-md border text-white transition-all duration-1000"
                  style={{
                    backgroundColor: `${currentSlideData.theme.primary}20`,
                    borderColor: `${currentSlideData.theme.primary}40`,
                  }}
                >
                  <feature.icon className="h-5 w-5" />
                  <span className="font-medium">{feature.text}</span>
                </div>
              ))}
            </div>

            {/* Enhanced CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-6 pt-6">
              <a
                href="#products"
                className="group flex items-center justify-center px-8 py-4 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-2xl text-white"
                style={{ backgroundColor: currentSlideData.theme.primary }}
              >
                <span>{currentSlideData.cta}</span>
                <ArrowRight className="ml-3 h-6 w-6 group-hover:translate-x-2 transition-transform duration-300" />
              </a>
              <button
                onClick={() => setShowProductShowcase(!showProductShowcase)}
                className="bg-white/20 backdrop-blur-md text-white border-2 border-white/30 hover:bg-white/30 px-8 py-4 rounded-xl font-semibold transition-all duration-300 flex items-center justify-center"
              >
                <Sparkles className="mr-3 h-5 w-5" />
                <span>View Product</span>
              </button>
            </div>
          </div>

          {/* Enhanced Product Showcase Grid */}
          <div
            className={`relative transition-all duration-1000 ${isVisible ? "animate-slide-in-right" : "opacity-0"}`}
          >
            <div className="bg-white/95 backdrop-blur-md rounded-3xl p-8 shadow-2xl">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Product Showcase</h3>
                <p className="text-gray-600">Swipe to explore our collection</p>
              </div>

              <div className="space-y-6">
                <Image
                  src={currentSlideData.product.image || "/placeholder.svg"}
                  alt={currentSlideData.product.name}
                  width={300}
                  height={300}
                  className="w-full h-64 object-cover rounded-2xl transition-all duration-1000"
                />

                <div className="text-center">
                  <h4 className="text-xl font-bold text-gray-900 mb-2">{currentSlideData.product.name}</h4>
                  <div className="flex items-center justify-center space-x-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${i < Math.floor(currentSlideData.product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"}`}
                      />
                    ))}
                    <span className="text-sm text-gray-600 ml-2">({currentSlideData.product.reviews})</span>
                  </div>

                  <div className="flex items-center justify-center space-x-2 mb-4">
                    <span className="text-3xl font-bold" style={{ color: currentSlideData.theme.primary }}>
                      ₹{currentSlideData.product.price}
                    </span>
                    {currentSlideData.product.originalPrice && (
                      <span className="text-xl text-gray-500 line-through">
                        ₹{currentSlideData.product.originalPrice}
                      </span>
                    )}
                  </div>

                  <button
                    className="w-full text-white py-3 rounded-xl font-semibold hover:opacity-90 transition-all duration-300"
                    style={{ backgroundColor: currentSlideData.theme.primary }}
                  >
                    Buy Now
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Slide Indicators */}
        <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2 flex space-x-3">
          {videoSlides.map((slide, index) => (
            <button
              key={slide.id}
              onClick={() => goToSlide(index)}
              className={`relative w-12 h-3 rounded-full transition-all duration-300 overflow-hidden ${
                index === currentSlide ? "scale-125 shadow-lg" : "hover:scale-110"
              }`}
              style={{
                backgroundColor: index === currentSlide ? slide.theme.primary : "rgba(255,255,255,0.5)",
              }}
            >
              {index === currentSlide && <div className="absolute inset-0 bg-white/30 animate-pulse rounded-full" />}
            </button>
          ))}
        </div>
      </div>

      {/* Video Gallery Modal */}
      {showVideoGallery && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900">Video Gallery</h2>
              <button onClick={() => setShowVideoGallery(false)} className="text-gray-500 hover:text-gray-700 text-2xl">
                ×
              </button>
            </div>

            <div className="p-6">
              <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-6">
                {videoSlides.map((slide, index) => (
                  <div
                    key={slide.id}
                    className={`relative cursor-pointer rounded-2xl overflow-hidden transition-all duration-300 hover:scale-105 ${
                      index === currentSlide ? "ring-4 ring-terracotta" : ""
                    }`}
                    onClick={() => {
                      goToSlide(index)
                      setShowVideoGallery(false)
                    }}
                  >
                    <Image
                      src={slide.thumbnail || "/placeholder.svg"}
                      alt={slide.title}
                      width={400}
                      height={250}
                      className="w-full h-48 object-cover"
                    />

                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-white font-bold text-lg mb-1">{slide.title}</h3>
                      <p className="text-white/80 text-sm">{slide.product.name}</p>
                    </div>

                    <div className="absolute top-4 right-4">
                      <div
                        className="text-white px-2 py-1 rounded-full text-xs font-bold"
                        style={{ backgroundColor: slide.theme.primary }}
                      >
                        {slide.product.badge || "NEW"}
                      </div>
                    </div>

                    {index === currentSlide && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="bg-white/20 backdrop-blur-md p-4 rounded-full">
                          <Play className="h-8 w-8 text-white" />
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Video Progress Indicator */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20">
        <div
          className="h-full transition-all duration-300"
          style={{
            width: `${((currentSlide + 1) / videoSlides.length) * 100}%`,
            backgroundColor: currentSlideData.theme.primary,
          }}
        />
      </div>
    </section>
  )
}
