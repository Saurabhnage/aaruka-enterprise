import Link from "next/link"
import { Leaf, Instagram, Mail, MapPin, Heart } from "lucide-react"

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-gray-900 text-white">
      {/* Main Footer */}
      <div className="section-padding">
        <div className="container-custom">
          <div className="grid lg:grid-cols-4 gap-12">
            {/* Brand Section */}
            <div className="lg:col-span-2">
              <Link href="#home" className="flex items-center space-x-2 mb-6">
                <div className="bg-terracotta p-2 rounded-full">
                  <Leaf className="h-6 w-6 text-white" />
                </div>
                <div>
                  <span className="text-xl font-playfair font-bold text-white">Aaruka</span>
                  <span className="text-sm text-gray-400 block leading-none">Enterprise</span>
                </div>
              </Link>

              <p className="text-gray-400 mb-6 leading-relaxed max-w-md">
                Nurturing your skin with the ancient wisdom of Multani Mitti. Pure, natural, and trusted by generations.
                Experience the healing power of authentic Fuller's Earth from Vadodara.
              </p>

              {/* Social Links */}
              <div className="flex space-x-4">
                <a
                  href="https://instagram.com/aarukaenterprise"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-gray-800 p-3 rounded-full hover:bg-pink-600 transition-colors duration-300"
                >
                  <Instagram className="h-5 w-5" />
                </a>
                <a
                  href="mailto:info@aarukaenterprise.com"
                  className="bg-gray-800 p-3 rounded-full hover:bg-blue-600 transition-colors duration-300"
                >
                  <Mail className="h-5 w-5" />
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="font-bold text-lg mb-4">Quick Links</h3>
              <ul className="space-y-3">
                <li>
                  <Link href="#home" className="text-gray-400 hover:text-white transition-colors duration-300">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="#products" className="text-gray-400 hover:text-white transition-colors duration-300">
                    Products
                  </Link>
                </li>
                <li>
                  <Link href="#testimonials" className="text-gray-400 hover:text-white transition-colors duration-300">
                    Reviews
                  </Link>
                </li>
                <li>
                  <Link href="#contact" className="text-gray-400 hover:text-white transition-colors duration-300">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>

            {/* Contact Info */}
            <div>
              <h3 className="font-bold text-lg mb-4">Contact</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-2 text-gray-400">
                  <MapPin className="h-4 w-4" />
                  <span className="text-sm">Vadodara, Gujarat, India</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-400">
                  <Mail className="h-4 w-4" />
                  <span className="text-sm">info@aarukaenterprise.com</span>
                </div>
              </div>

              {/* Payment Methods */}
              <div className="mt-6">
                <h4 className="font-semibold text-white mb-2">Secure Payments</h4>
                <div className="flex items-center space-x-2">
                  <div className="bg-blue-600 text-white px-2 py-1 rounded text-xs font-bold">Razorpay</div>
                  <div className="bg-green-600 text-white px-2 py-1 rounded text-xs font-bold">UPI</div>
                  <div className="bg-purple-600 text-white px-2 py-1 rounded text-xs font-bold">Cards</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="border-t border-gray-800">
        <div className="container-custom py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 text-center md:text-left">
            <div className="text-gray-400 text-sm">© {currentYear} Aaruka Enterprise. All rights reserved.</div>
            <div className="flex items-center justify-center space-x-1 text-gray-400 text-sm">
              <span>Made with</span>
              <Heart className="h-4 w-4 text-terracotta fill-current" />
              <span>in India</span>
            </div>
            <div className="text-center">
              <p className="text-terracotta font-medium italic text-lg">"Pure Earth. Pure Skin."</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
