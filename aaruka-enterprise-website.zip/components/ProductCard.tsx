"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { Star, ShoppingCart, Heart, Loader2 } from "lucide-react"

interface Product {
  id: string
  name: string
  price: number
  originalPrice?: number
  rating: number
  reviews: number
  image: string
  benefits: string[]
  weight: string
  description: string
}

interface ProductCardProps {
  product: Product
}

declare global {
  interface Window {
    Razorpay: any
  }
}

export default function ProductCard({ product }: ProductCardProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    email: "",
    phone: "",
  })
  const [showCheckout, setShowCheckout] = useState(false)

  const handleBuyNow = async () => {
    if (!customerInfo.name || !customerInfo.email) {
      setShowCheckout(true)
      return
    }

    setIsLoading(true)

    try {
      // Create order (works with or without real Razorpay credentials)
      const response = await fetch("/api/razorpay", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: product.price,
          currency: "INR",
          receipt: `receipt_${product.id}_${Date.now()}`,
          notes: {
            product_id: product.id,
            product_name: product.name,
            customer_name: customerInfo.name,
            customer_email: customerInfo.email,
          },
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to create order")
      }

      const order = await response.json()

      // Check if this is prototype mode (mock key)
      if (order.key === "rzp_test_prototype_key") {
        // Prototype mode - simulate successful payment
        console.log("Prototype mode: Simulating successful payment")
        setTimeout(() => {
          window.location.href = `/thank-you?payment_id=pay_prototype_${Date.now()}&order_id=${order.id}`
        }, 2000)
        return
      }

      // Production mode - use actual Razorpay
      if (typeof window.Razorpay === "undefined") {
        throw new Error("Razorpay SDK not loaded")
      }

      const options = {
        key: order.key,
        amount: order.amount,
        currency: order.currency,
        name: "Aaruka Enterprise",
        description: product.name,
        image: "/logo.png",
        order_id: order.id,
        prefill: {
          name: customerInfo.name,
          email: customerInfo.email,
          contact: customerInfo.phone,
        },
        theme: {
          color: "#CD853F",
        },
        handler: (response: any) => {
          console.log("Payment successful:", response)
          window.location.href = `/thank-you?payment_id=${response.razorpay_payment_id}&order_id=${response.razorpay_order_id}`
        },
        modal: {
          ondismiss: () => {
            setIsLoading(false)
          },
        },
      }

      const rzp = new window.Razorpay(options)
      rzp.open()
    } catch (error) {
      console.error("Payment error:", error)
      alert("Payment failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleCustomerInfoSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setShowCheckout(false)
    handleBuyNow()
  }

  return (
    <>
      <div className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 group">
        {/* Product Image */}
        <div className="relative overflow-hidden rounded-t-2xl">
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            width={400}
            height={300}
            className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
          />

          {/* Discount Badge */}
          {product.originalPrice && (
            <div className="absolute top-4 left-4 bg-terracotta text-white px-3 py-1 rounded-full text-sm font-semibold">
              {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
            </div>
          )}

          {/* Wishlist Button */}
          <button className="absolute top-4 right-4 bg-white/80 backdrop-blur-sm p-2 rounded-full hover:bg-white transition-colors duration-300">
            <Heart className="h-5 w-5 text-gray-600 hover:text-terracotta" />
          </button>
        </div>

        {/* Product Info */}
        <div className="p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-terracotta font-semibold uppercase tracking-wide">{product.weight}</span>
            <div className="flex items-center space-x-1">
              <Star className="h-4 w-4 text-yellow-400 fill-current" />
              <span className="text-sm font-medium">{product.rating}</span>
              <span className="text-sm text-gray-500">({product.reviews})</span>
            </div>
          </div>

          <h3 className="text-xl font-bold text-gray-900 mb-2">{product.name}</h3>
          <p className="text-gray-600 text-sm mb-4">{product.description}</p>

          {/* Benefits */}
          <div className="flex flex-wrap gap-2 mb-4">
            {product.benefits.slice(0, 2).map((benefit, index) => (
              <span key={index} className="bg-sage/10 text-sage text-xs px-2 py-1 rounded-full">
                {benefit}
              </span>
            ))}
          </div>

          {/* Price */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <span className="text-2xl font-bold text-gray-900">₹{product.price}</span>
              {product.originalPrice && (
                <span className="text-lg text-gray-500 line-through">₹{product.originalPrice}</span>
              )}
            </div>
          </div>

          {/* Buy Now Button */}
          <button
            onClick={handleBuyNow}
            disabled={isLoading}
            className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <div className="flex items-center justify-center">
                <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                Processing...
              </div>
            ) : (
              <div className="flex items-center justify-center">
                <ShoppingCart className="h-5 w-5 mr-2" />
                Buy Now (Demo)
              </div>
            )}
          </button>
        </div>
      </div>

      {/* Customer Info Modal */}
      {showCheckout && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Complete Your Purchase</h3>
            <p className="text-gray-600 mb-6">Please provide your details to proceed with the demo payment.</p>

            <form onSubmit={handleCustomerInfoSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  id="name"
                  required
                  value={customerInfo.name}
                  onChange={(e) => setCustomerInfo((prev) => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-terracotta focus:border-transparent"
                  placeholder="Enter your full name"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  id="email"
                  required
                  value={customerInfo.email}
                  onChange={(e) => setCustomerInfo((prev) => ({ ...prev, email: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-terracotta focus:border-transparent"
                  placeholder="Enter your email"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  id="phone"
                  value={customerInfo.phone}
                  onChange={(e) => setCustomerInfo((prev) => ({ ...prev, phone: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-terracotta focus:border-transparent"
                  placeholder="+91 98765 43210"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button type="button" onClick={() => setShowCheckout(false)} className="flex-1 btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="flex-1 btn-primary">
                  Proceed to Demo Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  )
}
