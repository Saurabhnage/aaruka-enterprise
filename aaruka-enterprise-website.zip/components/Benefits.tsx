import { Sparkles, Shield, Leaf, Heart, Zap, Sun } from "lucide-react"

export default function Benefits() {
  const benefits = [
    {
      icon: Sparkles,
      title: "Deep Cleansing",
      description: "Removes impurities, excess oil, and dead skin cells from deep within pores",
    },
    {
      icon: Shield,
      title: "Acne Control",
      description: "Natural antibacterial properties help prevent and treat acne breakouts",
    },
    {
      icon: Leaf,
      title: "Natural Detox",
      description: "Draws out toxins and pollutants, leaving skin refreshed and purified",
    },
    {
      icon: Heart,
      title: "Gentle on Skin",
      description: "Suitable for all skin types, including sensitive skin, with no harsh chemicals",
    },
    {
      icon: Zap,
      title: "Instant Glow",
      description: "Reveals brighter, more radiant skin with improved texture and tone",
    },
    {
      icon: Sun,
      title: "Sun Damage Repair",
      description: "Helps reduce tan, dark spots, and sun damage for even skin tone",
    },
  ]

  return (
    <section id="benefits" className="section-padding bg-white">
      <div className="container-custom">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Why <span className="text-gradient">Multani Mitti?</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            For centuries, Indian women have trusted Fuller's Earth for its remarkable skincare benefits. Discover the
            science behind this ancient beauty secret.
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="group p-6 rounded-2xl bg-earth-light hover:bg-white hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className="bg-terracotta/10 p-4 rounded-full w-16 h-16 mb-4 group-hover:bg-terracotta/20 transition-colors duration-300">
                <benefit.icon className="h-8 w-8 text-terracotta mx-auto" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{benefit.title}</h3>
              <p className="text-gray-700 leading-relaxed">{benefit.description}</p>
            </div>
          ))}
        </div>

        {/* Ayurvedic Heritage Section */}
        <div className="bg-gradient-to-r from-sage/10 to-terracotta/10 rounded-3xl p-8 md:p-12">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">
                Rooted in <span className="text-gradient">Ayurvedic Wisdom</span>
              </h3>
              <div className="space-y-4 text-gray-700">
                <p>
                  Multani Mitti, known as "Fuller's Earth" in English, has been a cornerstone of Ayurvedic skincare for
                  over 4,000 years. Ancient texts describe it as "Mrittika" - the earth that purifies.
                </p>
                <p>
                  Rich in minerals like magnesium, silica, and iron, our clay from Vadodara's soil carries the healing
                  properties that have been trusted by generations of Indian families.
                </p>
                <p>
                  Unlike synthetic products, Multani Mitti works in harmony with your skin's natural processes,
                  providing gentle yet effective care that stands the test of time.
                </p>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-white p-6 rounded-xl shadow-lg">
                <h4 className="font-bold text-gray-900 mb-2">Traditional Uses</h4>
                <ul className="text-gray-700 space-y-1">
                  <li>• Bridal beauty rituals</li>
                  <li>• Monsoon skincare</li>
                  <li>• Post-sun exposure treatment</li>
                  <li>• Hair and scalp cleansing</li>
                </ul>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-lg">
                <h4 className="font-bold text-gray-900 mb-2">Modern Science Says</h4>
                <ul className="text-gray-700 space-y-1">
                  <li>• Absorbs 2x its weight in oil</li>
                  <li>• pH balancing properties</li>
                  <li>• Rich in natural minerals</li>
                  <li>• Anti-inflammatory compounds</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
