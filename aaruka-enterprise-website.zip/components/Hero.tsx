import Image from "next/image"
import { ArrowRight, Star, Shield, Leaf } from "lucide-react"

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center hero-gradient overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23CD853F' fillOpacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
      </div>

      <div className="container-custom relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen py-20">
          {/* Content */}
          <div className="space-y-8 animate-fade-in-up">
            {/* Badge */}
            <div className="inline-flex items-center space-x-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg">
              <Star className="h-4 w-4 text-terracotta fill-current" />
              <span className="text-sm font-medium text-gray-700">4.9/5 from 1000+ customers</span>
            </div>

            {/* Main Heading */}
            <div className="space-y-4">
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight">
                <span className="text-gradient">Pure Earth.</span>
                <br />
                <span className="text-gradient">Pure Skin.</span>
              </h1>
              <p className="text-xl md:text-2xl text-gray-600 font-light">100% Organic Multani Mitti from Vadodara</p>
              <p className="text-lg text-gray-700 max-w-lg leading-relaxed">
                Experience the ancient beauty secrets of India with our authentic Fuller's Earth. Handcrafted with love,
                trusted by generations.
              </p>
            </div>

            {/* Features */}
            <div className="flex flex-wrap gap-6">
              <div className="flex items-center space-x-2">
                <Shield className="h-5 w-5 text-terracotta" />
                <span className="text-gray-700">100% Natural</span>
              </div>
              <div className="flex items-center space-x-2">
                <Leaf className="h-5 w-5 text-sage" />
                <span className="text-gray-700">Chemical-Free</span>
              </div>
              <div className="flex items-center space-x-2">
                <Star className="h-5 w-5 text-clay" />
                <span className="text-gray-700">Premium Quality</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <a href="#products" className="btn-primary group">
                Shop Now
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
              </a>
              <a href="#testimonials" className="btn-secondary">
                Read Reviews
              </a>
            </div>

            {/* Trust Indicators */}
            <div className="pt-8 border-t border-gray-200">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-terracotta">10K+</div>
                  <div className="text-sm text-gray-600">Happy Customers</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-terracotta">100%</div>
                  <div className="text-sm text-gray-600">Natural</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-terracotta">5★</div>
                  <div className="text-sm text-gray-600">Rating</div>
                </div>
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="relative animate-fade-in">
            <div className="relative z-10 animate-float">
              <Image
                src="/placeholder.svg?height=600&width=500"
                alt="Aaruka Enterprise Multani Mitti Products"
                width={500}
                height={600}
                className="rounded-2xl shadow-2xl"
                priority
              />
            </div>

            {/* Decorative Elements */}
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-terracotta/20 rounded-full blur-xl"></div>
            <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-sage/20 rounded-full blur-xl"></div>
          </div>
        </div>
      </div>
    </section>
  )
}
