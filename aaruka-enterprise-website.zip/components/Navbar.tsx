"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Menu, X, Leaf, ShoppingCart } from "lucide-react"

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <nav
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? "bg-white/95 backdrop-blur-md shadow-lg" : "bg-transparent"
      }`}
    >
      <div className="container-custom">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="#home" className="flex items-center space-x-2 group">
            <div className="bg-terracotta p-2 rounded-full group-hover:scale-110 transition-transform duration-300">
              <Leaf className="h-6 w-6 text-white" />
            </div>
            <div>
              <span className="text-xl font-playfair font-bold text-terracotta">Aaruka</span>
              <span className="text-sm text-gray-600 block leading-none">Enterprise</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link href="#home" className="text-gray-700 hover:text-terracotta transition-colors duration-300">
              Home
            </Link>
            <Link href="#about" className="text-gray-700 hover:text-terracotta transition-colors duration-300">
              About
            </Link>
            <Link href="#founder" className="text-gray-700 hover:text-terracotta transition-colors duration-300">
              Founder
            </Link>
            <Link href="#products" className="text-gray-700 hover:text-terracotta transition-colors duration-300">
              Products
            </Link>
            <Link href="#testimonials" className="text-gray-700 hover:text-terracotta transition-colors duration-300">
              Reviews
            </Link>
            <Link href="#contact" className="text-gray-700 hover:text-terracotta transition-colors duration-300">
              Contact
            </Link>
            <button className="btn-primary flex items-center space-x-2">
              <ShoppingCart className="h-5 w-5" />
              <span>Shop Now</span>
            </button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors duration-300"
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden bg-white border-t border-gray-200 shadow-lg">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <Link
                href="#home"
                className="block px-3 py-2 text-gray-700 hover:text-terracotta hover:bg-gray-50 rounded-md"
                onClick={() => setIsOpen(false)}
              >
                Home
              </Link>
              <Link
                href="#about"
                className="block px-3 py-2 text-gray-700 hover:text-terracotta hover:bg-gray-50 rounded-md"
                onClick={() => setIsOpen(false)}
              >
                About
              </Link>
              <Link
                href="#founder"
                className="block px-3 py-2 text-gray-700 hover:text-terracotta hover:bg-gray-50 rounded-md"
                onClick={() => setIsOpen(false)}
              >
                Founder
              </Link>
              <Link
                href="#products"
                className="block px-3 py-2 text-gray-700 hover:text-terracotta hover:bg-gray-50 rounded-md"
                onClick={() => setIsOpen(false)}
              >
                Products
              </Link>
              <Link
                href="#testimonials"
                className="block px-3 py-2 text-gray-700 hover:text-terracotta hover:bg-gray-50 rounded-md"
                onClick={() => setIsOpen(false)}
              >
                Reviews
              </Link>
              <Link
                href="#contact"
                className="block px-3 py-2 text-gray-700 hover:text-terracotta hover:bg-gray-50 rounded-md"
                onClick={() => setIsOpen(false)}
              >
                Contact
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
