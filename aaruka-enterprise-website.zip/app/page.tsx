import Navbar from "@/components/Navbar"
import VideoGalleryHero from "@/components/VideoGalleryHero"
import About from "@/components/About"
import FounderStory from "@/components/FounderStory"
import Benefits from "@/components/Benefits"
import Products from "@/components/Products"
import Testimonials from "@/components/Testimonials"
import Contact from "@/components/Contact"
import Footer from "@/components/Footer"
import WhatsAppFloat from "@/components/WhatsAppFloat"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <VideoGalleryHero />
      <About />
      <FounderStory />
      <Benefits />
      <Products />
      <Testimonials />
      <Contact />
      <Footer />
      <WhatsAppFloat />
    </main>
  )
}
