import type React from "react"
import type { Metadata } from "next"
import { Playfair_Display, Lato } from "next/font/google"
import "./globals.css"
import Script from "next/script"

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
})

const lato = Lato({
  weight: ["300", "400", "700"],
  subsets: ["latin"],
  variable: "--font-lato",
  display: "swap",
})

export const metadata: Metadata = {
  title: "Aaruka Enterprise - Pure Earth, Pure Skin | Natural Multani Mitti from Vadodara",
  description:
    "Shop authentic 100% organic Multani Mitti products from Aaruka Enterprise. Natural skincare solutions from Vadodara, India. Free shipping across India.",
  keywords:
    "Multani Mitti, Fuller's Earth, Natural Skincare, Organic Clay, Vadodara, Indian Beauty, Ayurveda, Face Pack, Hair Mask, Buy Online",
  authors: [{ name: "Aaruka Enterprise" }],
  openGraph: {
    title: "Aaruka Enterprise - Pure Earth, Pure Skin",
    description: "Shop authentic 100% organic Multani Mitti products. Natural skincare from Vadodara, India.",
    url: "https://aaruka-enterprise.vercel.app",
    siteName: "Aaruka Enterprise",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Aaruka Enterprise - Natural Multani Mitti Products",
      },
    ],
    locale: "en_IN",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Aaruka Enterprise - Pure Earth, Pure Skin",
    description: "Shop authentic 100% organic Multani Mitti products from Vadodara, India.",
    images: ["/og-image.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <Script src="https://checkout.razorpay.com/v1/checkout.js" strategy="beforeInteractive" />
      </head>
      <body className={`${playfair.variable} ${lato.variable} font-lato antialiased`}>{children}</body>
    </html>
  )
}
