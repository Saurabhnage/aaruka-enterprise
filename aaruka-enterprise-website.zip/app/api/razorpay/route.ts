import { type NextRequest, NextResponse } from "next/server"

/**
 * Prototype-only Razorpay route.
 * • Always returns mock order data.
 * • No SDK / no secret keys required – so it compiles on any build target.
 * • When you’re ready for production, replace this file with the
 *   real implementation that imports the Razorpay SDK.
 */

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { amount, currency = "INR", receipt, notes } = body

    if (!amount || amount < 1) {
      return NextResponse.json({ error: "Amount is required and must be greater than 0" }, { status: 400 })
    }

    // ----- MOCK ORDER -----
    const mockOrder = {
      key: "rzp_test_prototype_key", // Identifies demo mode on the client
      id: `order_${Date.now()}`,
      amount: Math.round(amount * 100),
      currency,
      receipt: receipt || `receipt_${Date.now()}`,
      notes: notes || {},
      status: "created",
    }

    return NextResponse.json(mockOrder)
  } catch (err) {
    console.error("Prototype order error:", err)
    return NextResponse.json({ error: "Failed to create mock order" }, { status: 500 })
  }
}
