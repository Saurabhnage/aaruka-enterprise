"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { CheckCircle, Package, Truck, Heart } from "lucide-react"

export default function ThankYou() {
  const searchParams = useSearchParams()
  const [paymentId, setPaymentId] = useState("")
  const [orderId, setOrderId] = useState("")

  useEffect(() => {
    const payment_id = searchParams.get("payment_id")
    const order_id = searchParams.get("order_id")

    if (payment_id) setPaymentId(payment_id)
    if (order_id) setOrderId(order_id)
  }, [searchParams])

  return (
    <div className="min-h-screen bg-earth-light flex items-center justify-center px-4">
      <div className="max-w-2xl w-full">
        {/* Success Card */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 text-center">
          {/* Success Icon */}
          <div className="bg-green-100 p-6 rounded-full w-24 h-24 mx-auto mb-8">
            <CheckCircle className="h-12 w-12 text-green-600 mx-auto" />
          </div>

          {/* Success Message */}
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Payment Successful!</h1>
          <p className="text-xl text-gray-600 mb-8">
            Thank you for choosing Aaruka Enterprise! Your order has been confirmed and we're preparing it for shipment.
          </p>

          {/* Order Details */}
          {(paymentId || orderId) && (
            <div className="bg-earth-light p-6 rounded-2xl mb-8">
              <h3 className="font-bold text-gray-900 mb-4">Order Details</h3>
              <div className="space-y-2 text-sm">
                {orderId && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Order ID:</span>
                    <span className="font-mono text-gray-900">{orderId}</span>
                  </div>
                )}
                {paymentId && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Payment ID:</span>
                    <span className="font-mono text-gray-900">{paymentId}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* What's Next */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <div className="text-center">
              <div className="bg-terracotta/10 p-4 rounded-full w-16 h-16 mx-auto mb-4">
                <Package className="h-8 w-8 text-terracotta mx-auto" />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">Order Processing</h4>
              <p className="text-gray-600 text-sm">We'll prepare your order within 24 hours</p>
            </div>
            <div className="text-center">
              <div className="bg-terracotta/10 p-4 rounded-full w-16 h-16 mx-auto mb-4">
                <Truck className="h-8 w-8 text-terracotta mx-auto" />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">Fast Shipping</h4>
              <p className="text-gray-600 text-sm">Free delivery within 3-5 business days</p>
            </div>
            <div className="text-center">
              <div className="bg-terracotta/10 p-4 rounded-full w-16 h-16 mx-auto mb-4">
                <Heart className="h-8 w-8 text-terracotta mx-auto" />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">Enjoy Your Glow</h4>
              <p className="text-gray-600 text-sm">Experience the magic of pure Multani Mitti</p>
            </div>
          </div>

          {/* Email Confirmation */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-8">
            <p className="text-blue-800 text-sm">
              📧 A confirmation email has been sent to your registered email address with order details and tracking
              information.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/#products" className="btn-primary">
              Continue Shopping
            </Link>
            <Link href="/#contact" className="btn-secondary">
              Contact Support
            </Link>
          </div>

          {/* Brand Quote */}
          <div className="mt-8 pt-8 border-t border-gray-200">
            <p className="text-terracotta font-medium italic text-lg">"Pure Earth. Pure Skin."</p>
            <p className="text-gray-600 text-sm mt-2">Thank you for choosing natural skincare with Aaruka Enterprise</p>
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-8 text-center">
          <p className="text-gray-600 text-sm">
            Need help? Contact us at{" "}
            <a href="mailto:info@aarukaenterprise.com" className="text-terracotta hover:underline">
              info@aarukaenterprise.com
            </a>{" "}
            or call{" "}
            <a href="tel:+919876543210" className="text-terracotta hover:underline">
              +91 98765 43210
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}
